﻿=== Red Radar Cursor Set ===

By: JDDellGuy (http://www.rw-designer.com/user/14944) josiah_deal@yahoo.com

Download: http://www.rw-designer.com/cursor-set/red-radar-cursors

Author's decription:

What I consider to be my finest cursor set so far.  I built this using a ''ton'' of layers.  I succeeded in finally creating the glassy effect I have been striving to accomplish and might create a tutorial on how to do it another time.  It is basically a set of cursors that are based on a spinning red radar- hence the name.  They contain very high quality animations.  Each frame of the spinning radar beam is only 10 degrees rotation- a total of 36 frames for each cursor with the radar in it.  I am not entirely satisfied with the "Link" and "Help" cursors, but I do not plan on improving them.

You may recolor, or alter them for yourself, but I do ask that you do not re-upload them as your own.

Please download, and COMMENT, and RATE!  I ''love'' it when you guys do that!  Feedback is fantastic!  [[image:icon-image/4575-16x16x32.png]]

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.