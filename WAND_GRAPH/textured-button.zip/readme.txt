﻿=== Textured Button Icon Set ===

By: Intellisthetics (http://www.rw-designer.com/user/28560)

Download: http://www.rw-designer.com/icon-set/textured-button

Author's decription:

Assorted Textured Glossy Button Icons : Beans, Fabric, Noodle, Worms, VooDoo, and Walnut Textures.

==========

License: Creative Commons - Noncommercial

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Noncommercial - You may not use this work for commercial purposes.